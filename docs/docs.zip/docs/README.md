# SuperLuminic Docs

>## Change the WORLD or go HOME
>*- StrongTax*
---

As we described on the [main website](https://superluminic.com), we are the first private space agency in Mexico.

![alt text](/assets/DesktopRocket.png "Provided by SuperLuminic.com")

## We know the Difficulty

We want this project to be alive, because when all the big countries start a big revolution in the outerspace, We want to be there, as a country and a dream.


